package com.example.apptodolist.ui.add_edit;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import com.example.apptodolist.R;
import com.example.apptodolist.data.model.Task;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AddEditActivity extends AppCompatActivity {
    private AddEditViewModel viewModel;
    private EditText edtTitle, edtDesc;
    private RadioButton rbWork, rbPersonal, rbHigh, rbMedium, rbLow;
    private Task currentTask;
    private TextView tvSelectDate;
    private String selectedDate = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit);
        tvSelectDate = findViewById(R.id.tvSelectDate);
        edtTitle = findViewById(R.id.edtTitle);
        edtDesc = findViewById(R.id.edtDesc);
        rbWork = findViewById(R.id.rbWork);
        rbPersonal = findViewById(R.id.rbPersonal);
        rbHigh = findViewById(R.id.rbHigh);
        rbMedium = findViewById(R.id.rbMedium);
        rbLow = findViewById(R.id.rbLow);
        Button btnSave = findViewById(R.id.btnSave);
        if (getIntent().getSerializableExtra("TASK_DATA") != null) {
            currentTask = (Task) getIntent().getSerializableExtra("TASK_DATA");
            selectedDate = currentTask.getDate();
            fillDataToUI();
        }
        else {
            selectedDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        }
        tvSelectDate.setText(selectedDate);
        tvSelectDate.setOnClickListener(v -> showDatePicker());
        viewModel = new ViewModelProvider(this).get(AddEditViewModel.class);
        viewModel.saveSuccessLive.observe(this, success -> {
            if (success) {
                Toast.makeText(this, "Lưu thành công!", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
        viewModel.messageLive.observe(this, msg -> Toast.makeText(this, msg, Toast.LENGTH_SHORT).show());
        btnSave.setOnClickListener(v -> {
            Toast.makeText(AddEditActivity.this, "Đang gửi dữ liệu...", Toast.LENGTH_SHORT).show();
            String title = edtTitle.getText().toString();
            String desc = edtDesc.getText().toString();
            String category = rbWork.isChecked() ? "Work" : "Personal";
            int priority = rbHigh.isChecked() ? 1 : (rbMedium.isChecked() ? 2 : 3);
            String dateToSave = selectedDate;
            if (currentTask == null) {
                Task newTask = new Task(title, desc, dateToSave, priority, category);
                viewModel.saveTask(newTask, false);
            }
            else {
                currentTask.setTitle(title);
                currentTask.setDescription(desc);
                currentTask.setCategory(category);
                currentTask.setPriority(priority);
                currentTask.setDate(dateToSave);
                viewModel.saveTask(currentTask, true);
            }
        });
    }
    private void fillDataToUI() {
        edtTitle.setText(currentTask.getTitle());
        edtDesc.setText(currentTask.getDescription());
        if ("Personal".equals(currentTask.getCategory())) rbPersonal.setChecked(true);
        else rbWork.setChecked(true);
        if (currentTask.getPriority() == 1) rbHigh.setChecked(true);
        else if (currentTask.getPriority() == 2) rbMedium.setChecked(true);
        else rbLow.setChecked(true);
    }
    private void showDatePicker() {
        Calendar calendar = Calendar.getInstance();
        try {
            String[] parts = selectedDate.split("-");
            int y = Integer.parseInt(parts[0]);
            int m = Integer.parseInt(parts[1]) - 1;
            int d = Integer.parseInt(parts[2]);
            calendar.set(y, m, d);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                (view, year, month, dayOfMonth) -> {
                    Calendar selectedCal = Calendar.getInstance();
                    selectedCal.set(year, month, dayOfMonth);
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                    selectedDate = sdf.format(selectedCal.getTime());
                    tvSelectDate.setText(selectedDate);
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        );
        datePickerDialog.show();
    }
}