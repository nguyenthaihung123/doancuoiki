package com.example.apptodolist.data.remote;

import com.example.apptodolist.data.model.Task;
import java.util.List;
import retrofit2.Call;
import retrofit2.http.*;

public interface ApiService {
    @GET("todolist/")
    Call<List<Task>> getAllTasks();
    @POST("todolist/")
    Call<Task> addTask(@Body Task task);
    @PUT("todolist/")
    Call<Task> updateTask(@Query("id") int id, @Body Task task);
    @DELETE("todolist/")
    Call<Void> deleteTask(@Query("id") int id);
}