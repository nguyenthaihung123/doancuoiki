package com.example.apptodolist.ui.calendar;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.apptodolist.data.model.Task;
import com.example.apptodolist.data.repository.TaskRepository;
import java.util.ArrayList;
import java.util.List;

public class CalendarViewModel extends ViewModel {
    private TaskRepository repository;
    public MutableLiveData<List<Task>> tasksForDateLive = new MutableLiveData<>();
    private List<Task> allTasks = new ArrayList<>();
    public CalendarViewModel() {
        repository = new TaskRepository();
    }
    public void loadTasks() {
        repository.getTasks(new TaskRepository.ApiCallback<List<Task>>() {
            @Override public void onSuccess(List<Task> result) {
                allTasks = result;
            }
            @Override public void onError(String msg) { }
        });
    }
    public void filterByDate(String dateStr) {
        List<Task> filtered = new ArrayList<>();
        for (Task t : allTasks) {
            if (t.getDate() != null && t.getDate().equals(dateStr)) {
                filtered.add(t);
            }
        }
        tasksForDateLive.setValue(filtered);
    }
}