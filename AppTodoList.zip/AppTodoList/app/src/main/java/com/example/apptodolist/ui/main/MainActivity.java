package com.example.apptodolist.ui.main;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.apptodolist.R;
import com.example.apptodolist.adapter.TaskAdapter;
import com.example.apptodolist.data.model.Task;
import com.example.apptodolist.interfaces.OnTaskActionListener;
import com.example.apptodolist.ui.add_edit.AddEditActivity;
import com.example.apptodolist.ui.calendar.CalendarActivity;
import com.example.apptodolist.ui.statistic.StatisticActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements OnTaskActionListener {
    private MainViewModel viewModel;
    private TaskAdapter adapter;
    private int currentTab = 0;
    private String currentSearch = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        viewModel = new ViewModelProvider(this).get(MainViewModel.class);
        setupViews();
        viewModel.taskListLive.observe(this, tasks -> adapter.setTaskList(tasks));
        viewModel.messageLive.observe(this, msg -> Toast.makeText(this, msg, Toast.LENGTH_SHORT).show());
        viewModel.loadTasks();
    }
    private void setupViews() {
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new TaskAdapter(this);
        recyclerView.setAdapter(adapter);
        SearchView searchView = findViewById(R.id.searchView);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) { return false; }
            @Override
            public boolean onQueryTextChange(String newText) {
                currentSearch = newText;
                viewModel.filter(currentSearch, currentTab);
                return true;
            }
        });
        TabLayout tabLayout = findViewById(R.id.tabLayout);
        tabLayout.addTab(tabLayout.newTab().setText("Tất cả"));
        tabLayout.addTab(tabLayout.newTab().setText("Công việc"));
        tabLayout.addTab(tabLayout.newTab().setText("Cá nhân"));
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                currentTab = tab.getPosition();
                viewModel.filter(currentSearch, currentTab);
            }
            @Override public void onTabUnselected(TabLayout.Tab tab) {}
            @Override public void onTabReselected(TabLayout.Tab tab) {}
        });
        FloatingActionButton fab = findViewById(R.id.fabAdd);
        fab.setOnClickListener(v -> {
            Intent intent = new Intent(this, AddEditActivity.class);
            startActivity(intent);
        });
        if (findViewById(R.id.btnCalendar) != null) {
            findViewById(R.id.btnCalendar).setOnClickListener(v -> {
                Intent intent = new Intent(this, CalendarActivity.class);
                startActivity(intent);
            });
        }
        if (findViewById(R.id.btnStatistic) != null) {
            findViewById(R.id.btnStatistic).setOnClickListener(v -> {
                Intent intent = new Intent(this, StatisticActivity.class);
                startActivity(intent);
            });
        }
    }
    @Override
    protected void onResume() {
        super.onResume();
        viewModel.loadTasks();
    }
    @Override
    public void onTaskClick(Task task) {
        Intent intent = new Intent(this, AddEditActivity.class);
        intent.putExtra("TASK_DATA", task);
        startActivity(intent);
    }
    @Override
    public void onTaskLongClick(Task task) {
        new AlertDialog.Builder(this)
                .setTitle("Xóa?")
                .setMessage("Bạn có chắc muốn xóa: " + task.getTitle())
                .setPositiveButton("Có", (d, w) -> viewModel.deleteTask(task.getId()))
                .setNegativeButton("Không", null).show();
    }
    @Override
    public void onTaskStatusChanged(Task task, boolean isCompleted) {
        viewModel.updateTaskStatus(task, isCompleted);
    }
}