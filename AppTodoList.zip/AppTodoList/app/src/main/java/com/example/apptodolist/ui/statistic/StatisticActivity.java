package com.example.apptodolist.ui.statistic;

import android.os.Bundle;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.apptodolist.R;
import com.example.apptodolist.data.model.Task;
import com.example.apptodolist.data.remote.ApiClient;
import com.example.apptodolist.data.remote.ApiService;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class StatisticActivity extends AppCompatActivity {
    private ProgressBar progressBarCircle;
    private TextView tvPercent, tvCompleted, tvPending;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistic);
        if (getSupportActionBar() != null) getSupportActionBar().hide();
        progressBarCircle = findViewById(R.id.progressBarCircle);
        tvPercent = findViewById(R.id.tvPercent);
        tvCompleted = findViewById(R.id.tvCompleted);
        tvPending = findViewById(R.id.tvPending);
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        loadStatistics();
    }

    private void loadStatistics() {
        ApiService apiService = ApiClient.getService();
        apiService.getAllTasks().enqueue(new Callback<List<Task>>() {
            @Override
            public void onResponse(Call<List<Task>> call, Response<List<Task>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<Task> taskList = response.body();
                    calculateAndDisplay(taskList);
                }
            }
            @Override
            public void onFailure(Call<List<Task>> call, Throwable t) {
                Toast.makeText(StatisticActivity.this, "Lỗi tải dữ liệu!", Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void calculateAndDisplay(List<Task> tasks) {
        int total = tasks.size();
        int completedCount = 0;
        for (Task task : tasks) {
            if (task.getStatus() == 1) {
                completedCount++;
            }
        }
        int pendingCount = total - completedCount;
        int percent = 0;
        if (total > 0) {
            percent = (completedCount * 100) / total;
        }
        tvCompleted.setText(String.valueOf(completedCount));
        tvPending.setText(String.valueOf(pendingCount));

        progressBarCircle.setProgress(percent);
        tvPercent.setText(percent + "%");
    }
}