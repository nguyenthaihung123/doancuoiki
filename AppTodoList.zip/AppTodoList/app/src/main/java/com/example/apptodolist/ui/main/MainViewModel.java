package com.example.apptodolist.ui.main;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.apptodolist.data.model.Task;
import com.example.apptodolist.data.repository.TaskRepository;
import java.util.ArrayList;
import java.util.List;

public class MainViewModel extends ViewModel {
    private TaskRepository repository;
    public MutableLiveData<List<Task>> taskListLive = new MutableLiveData<>();
    public MutableLiveData<String> messageLive = new MutableLiveData<>();
    private List<Task> originalList = new ArrayList<>();
    public MainViewModel() {
        repository = new TaskRepository();
    }
    public void loadTasks() {
        repository.getTasks(new TaskRepository.ApiCallback<List<Task>>() {
            @Override public void onSuccess(List<Task> result) {
                originalList = result;
                taskListLive.setValue(result);
            }
            @Override public void onError(String msg) { messageLive.setValue(msg); }
        });
    }
    public void updateTaskStatus(Task task, boolean isChecked) {
        task.setStatus(isChecked ? 1 : 0);
        repository.updateTask(task, new TaskRepository.ApiCallback<Task>() {
            @Override public void onSuccess(Task result) {}
            @Override public void onError(String msg) { messageLive.setValue(msg); }
        });
    }
    public void deleteTask(int id) {
        repository.deleteTask(id, new TaskRepository.ApiCallback<Void>() {
            @Override public void onSuccess(Void result) {
                messageLive.setValue("Đã xóa!");
                loadTasks();
            }
            @Override public void onError(String msg) { messageLive.setValue(msg); }
        });
    }
    public void filter(String query, int tabIndex) {
        List<Task> filtered = new ArrayList<>();
        for (Task t : originalList) {
            boolean matchTab = (tabIndex == 0) ||
                    (tabIndex == 1 && "Work".equals(t.getCategory())) ||
                    (tabIndex == 2 && "Personal".equals(t.getCategory()));
            boolean matchSearch = t.getTitle().toLowerCase().contains(query.toLowerCase());
            if (matchTab && matchSearch) filtered.add(t);
        }
        taskListLive.setValue(filtered);
    }
}