package com.example.apptodolist.data.model;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

public class Task implements Serializable {
    @SerializedName("id") private int id;
    @SerializedName("title") private String title;
    @SerializedName("description") private String description;
    @SerializedName("date") private String date;
    @SerializedName("status") private int status; // 0: Mới, 1: Xong
    @SerializedName("priority") private int priority;
    @SerializedName("category") private String category;
    public Task() {}
    public Task(String title, String description, String date, int priority, String category) {
        this.title = title;
        this.description = description;
        this.date = date;
        this.priority = priority;
        this.category = category;
        this.status = 0;
    }
    public int getId() {
        return id;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public void setStatus(int status) {
        this.status = status;
    }
    public int getStatus() {
        return status;
    }
    public String getDate() {
        return date;
    }
    public String getDescription() {
        return description;
    }
    public String getCategory() {
        return category;
    }
    public int getPriority() {
        return priority;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public void setPriority(int priority) {
        this.priority = priority;
    }
    public void setCategory(String category) {
        this.category = category;
    }

    public void setDate(String date) {
        this.date = date;
    }
}