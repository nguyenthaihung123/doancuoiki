package com.example.apptodolist.ui.add_edit;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.apptodolist.data.model.Task;
import com.example.apptodolist.data.repository.TaskRepository;

public class AddEditViewModel extends ViewModel {
    private TaskRepository repository;
    public MutableLiveData<Boolean> saveSuccessLive = new MutableLiveData<>();
    public MutableLiveData<String> messageLive = new MutableLiveData<>();
    public AddEditViewModel() {
        repository = new TaskRepository();
    }
    public void saveTask(Task task, boolean isUpdate) {
        if (task.getTitle().isEmpty()) {
            messageLive.setValue("Vui lòng nhập tiêu đề");
            return;
        }
        TaskRepository.ApiCallback<Task> callback = new TaskRepository.ApiCallback<Task>() {
            @Override public void onSuccess(Task result) { saveSuccessLive.setValue(true); }
            @Override public void onError(String msg) { messageLive.setValue(msg); }
        };
        if (isUpdate) {
            repository.updateTask(task, callback);
        }
        else {
            repository.addTask(task, callback);
        }
    }
}