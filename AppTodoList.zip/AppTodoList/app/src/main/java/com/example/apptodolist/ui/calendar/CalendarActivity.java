package com.example.apptodolist.ui.calendar;

import android.os.Bundle;
import android.widget.CalendarView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.apptodolist.R;
import com.example.apptodolist.adapter.TaskAdapter;
import com.example.apptodolist.data.model.Task;
import com.example.apptodolist.interfaces.OnTaskActionListener;
import java.util.ArrayList;
import java.util.Locale;

public class CalendarActivity extends AppCompatActivity {
    private CalendarViewModel viewModel;
    private TaskAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        CalendarView calendarView = findViewById(R.id.calendarView);
        RecyclerView recyclerCalendar = findViewById(R.id.recyclerCalendar);
        TextView tvSelectedDate = findViewById(R.id.tvSelectedDate);
        recyclerCalendar.setLayoutManager(new LinearLayoutManager(this));
        adapter = new TaskAdapter(new OnTaskActionListener() {
            @Override public void onTaskClick(Task task) {}
            @Override public void onTaskLongClick(Task task) {}
            @Override public void onTaskStatusChanged(Task task, boolean isCompleted) {}
        });
        recyclerCalendar.setAdapter(adapter);
        viewModel = new ViewModelProvider(this).get(CalendarViewModel.class);
        viewModel.loadTasks();
        viewModel.tasksForDateLive.observe(this, tasks -> adapter.setTaskList(tasks));
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                String dateStr = String.format(Locale.getDefault(), "%d-%02d-%02d", year, month + 1, dayOfMonth);
                tvSelectedDate.setText("Nhiệm vụ ngày: " + dateStr);
                viewModel.filterByDate(dateStr);
            }
        });
    }
}