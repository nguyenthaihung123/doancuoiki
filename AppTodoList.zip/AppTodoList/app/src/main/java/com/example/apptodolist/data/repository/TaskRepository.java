package com.example.apptodolist.data.repository;

import com.example.apptodolist.data.remote.ApiClient;
import com.example.apptodolist.data.remote.ApiService;
import com.example.apptodolist.data.model.Task;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TaskRepository {
    private ApiService apiService;
    public TaskRepository() {
        this.apiService = ApiClient.getService();
    }
    public interface ApiCallback<T> {
        void onSuccess(T result);
        void onError(String msg);
    }
    public void getTasks(ApiCallback<List<Task>> cb) {
        apiService.getAllTasks().enqueue(new Callback<List<Task>>() {
            @Override public void onResponse(Call<List<Task>> c, Response<List<Task>> r) {
                if(r.isSuccessful()) cb.onSuccess(r.body());
                else cb.onError("Lỗi server");
            }
            @Override public void onFailure(Call<List<Task>> c, Throwable t) { cb.onError(t.getMessage()); }
        });
    }
    public void addTask(Task t, ApiCallback<Task> cb) {
        apiService.addTask(t).enqueue(wrapCallback(cb));
    }
    public void updateTask(Task t, ApiCallback<Task> cb) {
        apiService.updateTask(t.getId(), t).enqueue(wrapCallback(cb));
    }
    public void deleteTask(int id, ApiCallback<Void> cb) {
        apiService.deleteTask(id).enqueue(new Callback<Void>() {
            @Override public void onResponse(Call<Void> c, Response<Void> r) { if(r.isSuccessful()) cb.onSuccess(null); }
            @Override public void onFailure(Call<Void> c, Throwable t) { cb.onError(t.getMessage()); }
        });
    }
    private <T> Callback<T> wrapCallback(ApiCallback<T> cb) {
        return new Callback<T>() {
            @Override public void onResponse(Call<T> c, Response<T> r) { if(r.isSuccessful()) cb.onSuccess(r.body()); }
            @Override public void onFailure(Call<T> c, Throwable t) { cb.onError(t.getMessage()); }
        };
    }
}