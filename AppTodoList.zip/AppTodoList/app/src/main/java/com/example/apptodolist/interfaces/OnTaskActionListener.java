package com.example.apptodolist.interfaces;

import com.example.apptodolist.data.model.Task;

public interface OnTaskActionListener {
    void onTaskClick(Task task);
    void onTaskLongClick(Task task);
    void onTaskStatusChanged(Task task, boolean isCompleted);
}