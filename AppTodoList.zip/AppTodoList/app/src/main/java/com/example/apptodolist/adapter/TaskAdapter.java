package com.example.apptodolist.adapter;

import android.graphics.Color;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.apptodolist.R;
import com.example.apptodolist.data.model.Task;
import com.example.apptodolist.interfaces.OnTaskActionListener;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> {
    private List<Task> list;
    private OnTaskActionListener listener;
    public TaskAdapter(OnTaskActionListener listener) {
        this.listener = listener;
    }
    public void setTaskList(List<Task> list) {
        this.list = list;
        notifyDataSetChanged();
    }
    @NonNull @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_task, parent, false);
        return new TaskViewHolder(view);
    }
    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        if (list == null) return;
        Task task = list.get(position);
        holder.tvTitle.setText(task.getTitle());
        holder.tvDate.setText(task.getDate());
        if (task.getStatus() == 1) {
            holder.tvRemaining.setVisibility(View.GONE);
        }
        else {
            holder.tvRemaining.setVisibility(View.VISIBLE);
            calculateDeadline(task.getDate(), holder.tvRemaining);
        }
        holder.cbStatus.setOnCheckedChangeListener(null);
        holder.cbStatus.setChecked(task.getStatus() == 1);
        updateStrikeThrough(holder.tvTitle, task.getStatus() == 1);
        int colorRes = Color.parseColor("#FFC107");
        if (task.getPriority() == 1) colorRes = Color.parseColor("#F44336");
        else if (task.getPriority() == 3) colorRes = Color.parseColor("#4CAF50");
        holder.viewPriority.setBackgroundColor(colorRes);
        holder.itemView.setOnClickListener(v -> listener.onTaskClick(task));
        holder.btnDelete.setOnClickListener(v -> listener.onTaskLongClick(task));
        holder.itemView.setOnLongClickListener(v -> { listener.onTaskLongClick(task); return true; });
        holder.cbStatus.setOnCheckedChangeListener((v, isChecked) -> {
            listener.onTaskStatusChanged(task, isChecked);
            updateStrikeThrough(holder.tvTitle, isChecked);
            if (isChecked) holder.tvRemaining.setVisibility(View.GONE);
            else {
                holder.tvRemaining.setVisibility(View.VISIBLE);
                calculateDeadline(task.getDate(), holder.tvRemaining);
            }
        });
    }
    private void calculateDeadline(String targetDateStr, TextView tv) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        try {
            Date targetDate = sdf.parse(targetDateStr);
            Calendar todayCal = Calendar.getInstance();
            todayCal.set(Calendar.HOUR_OF_DAY, 0);
            todayCal.set(Calendar.MINUTE, 0);
            todayCal.set(Calendar.SECOND, 0);
            todayCal.set(Calendar.MILLISECOND, 0);
            Date today = todayCal.getTime();
            if (targetDate != null) {
                long diffInMillis = targetDate.getTime() - today.getTime();
                long daysDiff = TimeUnit.DAYS.convert(diffInMillis, TimeUnit.MILLISECONDS);
                if (daysDiff < 0) {
                    tv.setText("Quá hạn " + Math.abs(daysDiff) + " ngày");
                    tv.setTextColor(Color.RED);
                }
                else if (daysDiff == 0) {
                    tv.setText("Hạn chót hôm nay");
                    tv.setTextColor(Color.parseColor("#FF9800"));
                }
                else if (daysDiff == 1) {
                    tv.setText("Ngày mai đến hạn");
                    tv.setTextColor(Color.parseColor("#2196F3"));
                }
                else {
                    tv.setText("Còn " + daysDiff + " ngày");
                    tv.setTextColor(Color.parseColor("#4CAF50"));
                }
            }
        }
        catch (Exception e) {
            tv.setText("");
        }
    }
    private void updateStrikeThrough(TextView tv, boolean isChecked) {
        if (isChecked) {
            tv.setPaintFlags(tv.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            tv.setTextColor(Color.GRAY);
        }
        else {
            tv.setPaintFlags(tv.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
            tv.setTextColor(Color.BLACK);
        }
    }
    @Override public int getItemCount() { return list == null ? 0 : list.size(); }
    class TaskViewHolder extends RecyclerView.ViewHolder {
        TextView tvDate;
        TextView tvTitle;
        TextView tvRemaining;
        CheckBox cbStatus;
        View viewPriority;
        ImageButton btnDelete;
        public TaskViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            cbStatus = itemView.findViewById(R.id.cbStatus);
            viewPriority = itemView.findViewById(R.id.viewPriority);
            tvDate = itemView.findViewById(R.id.tvDate);
            btnDelete = itemView.findViewById(R.id.btnDelete);
            tvRemaining = itemView.findViewById(R.id.tvRemaining);
        }
    }
}