package com.example.apptodolist.utils;

public class Constants {
    public static final String BASE_URL = "http://192.168.150.80/api/";
}
