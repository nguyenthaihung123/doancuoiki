package com.example.apptodolist.ui.statistic;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.apptodolist.data.model.Task;
import com.example.apptodolist.data.repository.TaskRepository;
import java.util.List;

public class StatisticViewModel extends ViewModel {
    private TaskRepository repository;
    public MutableLiveData<Integer> totalCountLive = new MutableLiveData<>();
    public MutableLiveData<Integer> completedCountLive = new MutableLiveData<>();
    public MutableLiveData<Integer> pendingCountLive = new MutableLiveData<>();
    public MutableLiveData<Integer> percentLive = new MutableLiveData<>();
    public StatisticViewModel() {
        repository = new TaskRepository();
    }
    public void calculateStatistics() {
        repository.getTasks(new TaskRepository.ApiCallback<List<Task>>() {
            @Override
            public void onSuccess(List<Task> tasks) {
                int total = tasks.size();
                int completed = 0;
                for (Task t : tasks) {
                    if (t.getStatus() == 1) completed++;
                }
                int pending = total - completed;
                int percent = (total == 0) ? 0 : (completed * 100 / total);
                totalCountLive.setValue(total);
                completedCountLive.setValue(completed);
                pendingCountLive.setValue(pending);
                percentLive.setValue(percent);
            }
            @Override public void onError(String msg) {}
        });
    }
}